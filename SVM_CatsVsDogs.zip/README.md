
# SVM Classifier - Cats vs Dogs

This project uses a Support Vector Machine (SVM) to classify images of cats and dogs.

## Dataset
Download the dataset from: https://www.kaggle.com/c/dogs-vs-cats/data
Extract the images into a folder named `data/train` before running the script.

## Files
- `svm_cats_dogs.py`: Python script to preprocess data and train the SVM model.
- `README.md`: Instructions.

## Requirements
- Python 3.x
- scikit-learn
- numpy
- opencv-python

## Run
```bash
python svm_cats_dogs.py
```
